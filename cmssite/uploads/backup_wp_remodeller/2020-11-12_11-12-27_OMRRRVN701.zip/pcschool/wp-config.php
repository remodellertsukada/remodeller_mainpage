<?php
/**
 * WordPress の基本設定
 *
 * このファイルは、インストール時に wp-config.php 作成ウィザードが利用します。
 * ウィザードを介さずにこのファイルを "wp-config.php" という名前でコピーして
 * 直接編集して値を入力してもかまいません。
 *
 * このファイルは、以下の設定を含みます。
 *
 * * MySQL 設定
 * * 秘密鍵
 * * データベーステーブル接頭辞
 * * ABSPATH
 *
 * @link https://ja.wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// 注意:
// Windows の "メモ帳" でこのファイルを編集しないでください !
// 問題なく使えるテキストエディタ
// (http://wpdocs.osdn.jp/%E7%94%A8%E8%AA%9E%E9%9B%86#.E3.83.86.E3.82.AD.E3.82.B9.E3.83.88.E3.82.A8.E3.83.87.E3.82.A3.E3.82.BF 参照)
// を使用し、必ず UTF-8 の BOM なし (UTF-8N) で保存してください。

// ** MySQL 設定 - この情報はホスティング先から入手してください。 ** //
/** WordPress のためのデータベース名 */
define( 'DB_NAME', 'remo21club_wp2' );

/** MySQL データベースのユーザー名 */
define( 'DB_USER', 'remo21club_wp2' );

/** MySQL データベースのパスワード */
define( 'DB_PASSWORD', 'ctnxvonw5j' );

/** MySQL のホスト名 */
define( 'DB_HOST', 'mysql10087.xserver.jp' );

/** データベースのテーブルを作成する際のデータベースの文字セット */
define( 'DB_CHARSET', 'utf8' );

/** データベースの照合順序 (ほとんどの場合変更する必要はありません) */
define( 'DB_COLLATE', '' );

/**#@+
 * 認証用ユニークキー
 *
 * それぞれを異なるユニーク (一意) な文字列に変更してください。
 * {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org の秘密鍵サービス} で自動生成することもできます。
 * 後でいつでも変更して、既存のすべての cookie を無効にできます。これにより、すべてのユーザーを強制的に再ログインさせることになります。
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'SBOU[$OV7Mn1Cx7Byqvu^M/H9:-oAm:~m0A[v)PhEe^-#(zg@q3OE0#(Uh{2O}7O' );
define( 'SECURE_AUTH_KEY',  'vi3B_)]Z6a%B-@1_$2i1Vn-?/W~]yaKK178@}BT<)&(j<Ic@%B<<m4) E5aY&TZ%' );
define( 'LOGGED_IN_KEY',    '.28IWXvXSX8Y5>lh+%Rz5+9c9Fd8O@GqYVS5g`:^r23QuVt>ftmg`dcsqytL}]_K' );
define( 'NONCE_KEY',        'PjT8,-eFf{%9Q4cT45%OZd?2R9-)@a-Rk?$J6/>VC-`X!#gN.lte(qrS,`).u,jH' );
define( 'AUTH_SALT',        '^R:jNdpZ&{9j-3MBO*IDv-q7~x|@_}Zw!5M ~<TFVOR4!S>8oZK!Dr-c3Q(|Ir-`' );
define( 'SECURE_AUTH_SALT', 'iH<Ok~F9nt*9|?9@RGwexn^7![MAWNE0cw|qfF~kHiV1N1#[ABeSBEOo.N-j>CC3' );
define( 'LOGGED_IN_SALT',   '#GabL=pXhKYGa*^OxGLDx#Z(j}dFYGL7$^G_SE+=MV?8x53X{-G4-J.LEP`n!{l]' );
define( 'NONCE_SALT',       'b8_pG]o-;/c,=z&%bte*[Lz$VrC[H XSgT;3`<[g2<nM9j&+Xo/}^F8H]&ZoF=!%' );
define( 'WP_CACHE_KEY_SALT','cWv7r?/|lyg-e!=!+eji96z`6i.+N=)96284juHSp{f5kIlR[Nw@[_FbFd2*oqnl' );

/**#@-*/

/**
 * WordPress データベーステーブルの接頭辞
 *
 * それぞれにユニーク (一意) な接頭辞を与えることで一つのデータベースに複数の WordPress を
 * インストールすることができます。半角英数字と下線のみを使用してください。
 */
$table_prefix = 'wp_';

/**
 * 開発者へ: WordPress デバッグモード
 *
 * この値を true にすると、開発中に注意 (notice) を表示します。
 * テーマおよびプラグインの開発者には、その開発環境においてこの WP_DEBUG を使用することを強く推奨します。
 *
 * その他のデバッグに利用できる定数についてはドキュメンテーションをご覧ください。
 *
 * @link https://ja.wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* 編集が必要なのはここまでです ! WordPress でのパブリッシングをお楽しみください。 */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';

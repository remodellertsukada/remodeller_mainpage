<?php
/**
 * WordPress の基本設定
 *
 * このファイルは、インストール時に wp-config.php 作成ウィザードが利用します。
 * ウィザードを介さずにこのファイルを "wp-config.php" という名前でコピーして
 * 直接編集して値を入力してもかまいません。
 *
 * このファイルは、以下の設定を含みます。
 *
 * * MySQL 設定
 * * 秘密鍵
 * * データベーステーブル接頭辞
 * * ABSPATH
 *
 * @link https://ja.wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// 注意:
// Windows の "メモ帳" でこのファイルを編集しないでください !
// 問題なく使えるテキストエディタ
// (http://wpdocs.osdn.jp/%E7%94%A8%E8%AA%9E%E9%9B%86#.E3.83.86.E3.82.AD.E3.82.B9.E3.83.88.E3.82.A8.E3.83.87.E3.82.A3.E3.82.BF 参照)
// を使用し、必ず UTF-8 の BOM なし (UTF-8N) で保存してください。

// ** MySQL 設定 - この情報はホスティング先から入手してください。 ** //
/** WordPress のためのデータベース名 */
define( 'DB_NAME', 'remo21club_wp1' );

/** MySQL データベースのユーザー名 */
define( 'DB_USER', 'remo21club_wp1' );

/** MySQL データベースのパスワード */
define( 'DB_PASSWORD', '92g4cq7ejz' );

/** MySQL のホスト名 */
define( 'DB_HOST', 'mysql10087.xserver.jp' );

/** データベースのテーブルを作成する際のデータベースの文字セット */
define( 'DB_CHARSET', 'utf8' );

/** データベースの照合順序 (ほとんどの場合変更する必要はありません) */
define( 'DB_COLLATE', '' );

/**#@+
 * 認証用ユニークキー
 *
 * それぞれを異なるユニーク (一意) な文字列に変更してください。
 * {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org の秘密鍵サービス} で自動生成することもできます。
 * 後でいつでも変更して、既存のすべての cookie を無効にできます。これにより、すべてのユーザーを強制的に再ログインさせることになります。
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'OjXLNbZ:A(,;zKBo,~]4JdD =FyW(:)NC 3Ig%MmI.a612m<]j+%5ZJ575ZXS8@{' );
define( 'SECURE_AUTH_KEY',  'MBMoZIA[~L#>LAG;}<U_{~IaptS#=C<B6]e3[<0Usw9/Ezyx!s%2P|Ewwj*GN1|T' );
define( 'LOGGED_IN_KEY',    'x1{-tUnLEmR{2`|62V{ggI(~1}_zb`$>HRM)f_jC(}S9Fe9COLLc!oTa&u>|g2$i' );
define( 'NONCE_KEY',        'pri[W_JWW0V~1~,3:x&zuPM,lZnLB<$~uy@[sQr ^@x7#f>fOD?r@#6-CVhmBH.t' );
define( 'AUTH_SALT',        'Xc:B24ln_i7v[ ;olEA C-_-+b &{crQ!W.`(Dkh=NU0>P-emYaYnk^*iR:+61=3' );
define( 'SECURE_AUTH_SALT', 'oiv.nXy2$a@vK=U~?f$L&Ah9u^k6rPJT}tPOyl4xfB/CAi>^qk@Y/zbc%@6NlTLd' );
define( 'LOGGED_IN_SALT',   '=_151]aKU|&40C9W3 zBPS hiL}vur6e9G1}0`*t<8Er+,Qzkhx)jYG_NTmo:<X{' );
define( 'NONCE_SALT',       '2R-I Z0- OmfB9pWGznCP/x(4ZDqQH;AD,:;B[_=DR{Dvt}r4svzU`ZqQSqmZety' );
define( 'WP_CACHE_KEY_SALT','=t24}]R`Ufc:`rYmPTZsLoFwLl<P~OE_=-r2!#x,LXQnC,+!^0Us;10y@va.4_Eg' );

/**#@-*/

/**
 * WordPress データベーステーブルの接頭辞
 *
 * それぞれにユニーク (一意) な接頭辞を与えることで一つのデータベースに複数の WordPress を
 * インストールすることができます。半角英数字と下線のみを使用してください。
 */
$table_prefix = 'wp_';

/**
 * 開発者へ: WordPress デバッグモード
 *
 * この値を true にすると、開発中に注意 (notice) を表示します。
 * テーマおよびプラグインの開発者には、その開発環境においてこの WP_DEBUG を使用することを強く推奨します。
 *
 * その他のデバッグに利用できる定数についてはドキュメンテーションをご覧ください。
 *
 * @link https://ja.wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* 編集が必要なのはここまでです ! WordPress でのパブリッシングをお楽しみください。 */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
